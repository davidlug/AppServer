package SchedulingAlgorithm;

public class PlayingLocation {
    
    private String facility;

    private String rink;

    private boolean premium;

    public PlayingLocation(String facility, String rink, boolean premium)
    {
        this.facility = facility;
        this.rink = rink;
        this.premium = premium;
    }
}
